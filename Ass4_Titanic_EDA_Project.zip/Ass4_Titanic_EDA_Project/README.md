# Titanic EDA Project

This project performs Exploratory Data Analysis (EDA) on the Titanic dataset using Pandas, Seaborn, and Matplotlib.

## Folder structure
- data/ - Contains titanic.csv dataset.
- notebooks/ - Contains EDA_Titanic.ipynb Jupyter Notebook.
- requirements.txt - Python packages to install.

## How to run
1. Install dependencies:
2. Open notebook in VS Code or run:

## Notes
- Highlighted top 5 insights inside notebook.
- Feature engineering created FamilySize.